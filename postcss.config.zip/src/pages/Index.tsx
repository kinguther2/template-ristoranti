
import React from 'react';
import Home from './Home';

const Index: React.FC = () => {
  return <Home />;
};

export default Index;
